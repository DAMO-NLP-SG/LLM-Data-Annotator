### Installation

```
conda create -n SimpleRC python=3.7 -y
conda activate SimpleRC
pip install torch==1.10.0 --extra-index-url https://download.pytorch.org/whl/cu113
pip install -r requirements.txt
```

### Data

Unzip the data so there are the following files:

`data/new_split/new_train.json`
`data/new_split/new_dev.json`
`data/new_split/new_test.json`
`mkdir -p outputs/data/span_aste`

### Training

```
python main.py run_train \
--path_train data/new_split/new_train.json \
--path_test data/new_split/new_train.json \
--epochs 3
```
